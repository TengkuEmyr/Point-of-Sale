<?php 

$lang["item_kits_add_item"] = "Neuer Artikel";
$lang["item_kits_cannot_be_deleted"] = "Konnte Artikel-Set(s) nicht löschen";
$lang["item_kits_confirm_delete"] = "Wollen Sie die gewählten Artikel-Sets wirklich löschen?";
$lang["item_kits_description"] = "Beschreibung Artikel-Set";
$lang["item_kits_error_adding_updating"] = "Fehler beim Hinzufügen/Ändern";
$lang["item_kits_info"] = "Artikel-Set Information";
$lang["item_kits_item"] = "Artikel";
$lang["item_kits_items"] = "Artikel";
$lang["item_kits_kit"] = "Set-ID";
$lang["item_kits_name"] = "Name";
$lang["item_kits_new"] = "Neues Artikel-Set";
$lang["item_kits_no_item_kits_to_display"] = "Keine Artikel-Sets zum Anzeigen";
$lang["item_kits_none_selected"] = "Sie haben keine Artikel-Sets ausgewählt";
$lang["item_kits_one_or_multiple"] = "Artikel-Set(s)";
$lang["item_kits_quantity"] = "Menge";
$lang["item_kits_successful_adding"] = "Artikel-Set erfolgreich hinzugefügt";
$lang["item_kits_successful_deleted"] = "Löschung erfolgreich";
$lang["item_kits_successful_updating"] = "Änderung erfolgreich";
$lang["item_kits_update"] = "Artikel-Set ändern";
