<?php 

$lang["item_kits_add_item"] = "新增套件";
$lang["item_kits_cannot_be_deleted"] = "無法刪除產品套件";
$lang["item_kits_confirm_delete"] = "你確定你要刪除選取的產品套件嗎？";
$lang["item_kits_description"] = "產品套件描述";
$lang["item_kits_error_adding_updating"] = "新增/更新產品套件錯誤";
$lang["item_kits_info"] = "產品套件資料";
$lang["item_kits_item"] = "產品";
$lang["item_kits_items"] = "產品";
$lang["item_kits_kit"] = "Kit Id";
$lang["item_kits_name"] = "產品套件";
$lang["item_kits_new"] = "新增產品套件";
$lang["item_kits_no_item_kits_to_display"] = "沒有產品套件";
$lang["item_kits_none_selected"] = "沒有選擇任何產品套件";
$lang["item_kits_one_or_multiple"] = "產品套件";
$lang["item_kits_quantity"] = "數量";
$lang["item_kits_successful_adding"] = "新增產品套件成功";
$lang["item_kits_successful_deleted"] = "刪除成功";
$lang["item_kits_successful_updating"] = "更新產品套件成功";
$lang["item_kits_update"] = "更新產品套件";
