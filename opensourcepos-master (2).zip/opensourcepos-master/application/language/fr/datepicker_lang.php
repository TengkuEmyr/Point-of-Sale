<?php 

$lang["datepicker_today"] = "Aujourd'hui";
$lang["datepicker_weekstart"] = "1";
$lang["datepicker_all_time"] = "Depuis le début";
$lang["datepicker_last_7"] = "Ces 7 derniers jours";
$lang["datepicker_last_30"] = "Ces 30 derniers jours";
$lang["datepicker_last_month"] = "Le mois dernier";
$lang["datepicker_last_year"] = "L'année passée";
$lang["datepicker_this_month"] = "Ce mois";
$lang["datepicker_this_month_last_year"] = "Même mois de l'Année Dernière";
$lang["datepicker_same_month_to_today"] = "Ce mois-ci à aujourd'hui";
$lang["datepicker_same_month_to_same_day_last_year"] = "Même mois au même jour que l'an dernier";
$lang["datepicker_this_year"] = "Cette Année";
$lang["datepicker_today_last_year"] = "Même jour l'année passée";
$lang["datepicker_yesterday"] = "Hier";
$lang["datepicker_apply"] = "Appliquer";
$lang["datepicker_cancel"] = "Annuler la Vente";
$lang["datepicker_from"] = "De";
$lang["datepicker_to"] = "To";
$lang["datepicker_custom"] = "Personnaliser";
