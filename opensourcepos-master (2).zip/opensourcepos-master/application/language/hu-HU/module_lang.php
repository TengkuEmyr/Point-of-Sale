<?php 

$lang["module_config"] = "Bolt beállítás";
$lang["module_config_desc"] = "Bolt beállításainak módosítása";
$lang["module_customers"] = "Vevők";
$lang["module_customers_desc"] = "Vevők hozzáadása, módosítása, törlése és keresése";
$lang["module_employees"] = "Dolgozók";
$lang["module_employees_desc"] = "Dolgozók hozzáadása, módosítása, törlése és keresése";
$lang["module_giftcards"] = "Utalvány";
$lang["module_giftcards_desc"] = "Ajándékutalványok hozzáadása, módosítása, törlése és keresése";
$lang["module_home"] = "Kezdőlap";
$lang["module_item_kits"] = "Termék csomagok";
$lang["module_item_kits_desc"] = "Termék csomagok hozzáadása, módosítása, törlése és keresése";
$lang["module_items"] = "Termékek";
$lang["module_items_desc"] = "Termékek hozzáadása, módosítása, törlése és keresése";
$lang["module_receivings"] = "Áruátvétel";
$lang["module_receivings_desc"] = "Beszállítóktól érkező áruk átvétele";
$lang["module_reports"] = "Riportok";
$lang["module_reports_desc"] = "Riportok megtekintése és generálása";
$lang["module_sales"] = "Értékesítés";
$lang["module_sales_desc"] = "Termékek értékesítése és visszavétele";
$lang["module_suppliers"] = "Beszállítók";
$lang["module_suppliers_desc"] = "Beszállítók hozzáadása, módosítása, törlése és keresése";
$lang["module_messages"] = "Messages";
$lang["module_messages_desc"] = "Send Messages to Customers, Suppliers, Employees et al.";
