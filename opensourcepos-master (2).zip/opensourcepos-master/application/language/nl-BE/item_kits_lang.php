<?php 

$lang["item_kits_add_item"] = "Nieuw Product";
$lang["item_kits_cannot_be_deleted"] = "De sets konden niet worden verwijderd";
$lang["item_kits_confirm_delete"] = "Bent u zeker dat u de geselecteerde sets wil verwijderen?";
$lang["item_kits_description"] = "Omschrijving";
$lang["item_kits_error_adding_updating"] = "Fout bij het toevoegen/aanpassen van een set";
$lang["item_kits_info"] = "Product Set Info";
$lang["item_kits_item"] = "Product";
$lang["item_kits_items"] = "Producten";
$lang["item_kits_kit"] = "Kit Id";
$lang["item_kits_name"] = "Naam";
$lang["item_kits_new"] = "Nieuwe Set";
$lang["item_kits_no_item_kits_to_display"] = "Geen sets gevonden";
$lang["item_kits_none_selected"] = "U hebt geen sets geselecteerd";
$lang["item_kits_one_or_multiple"] = "Product set(s) verwijderd";
$lang["item_kits_quantity"] = "In stock";
$lang["item_kits_successful_adding"] = "Product set succesvol toegevoegd";
$lang["item_kits_successful_deleted"] = "Er werd(en)";
$lang["item_kits_successful_updating"] = "Wijzigingen product set bewaard";
$lang["item_kits_update"] = "Bewaar Set";
