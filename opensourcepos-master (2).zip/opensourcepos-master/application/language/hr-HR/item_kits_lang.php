<?php 

$lang["item_kits_add_item"] = "Dodaj artikl";
$lang["item_kits_cannot_be_deleted"] = "Ne možete obrisati normativ(e)";
$lang["item_kits_confirm_delete"] = "Jeste li sigurni da želite obrisati normativ";
$lang["item_kits_description"] = "Opis normativa";
$lang["item_kits_error_adding_updating"] = "Greška kod dodavanja/ažuriranja normativa";
$lang["item_kits_info"] = "Info normativa";
$lang["item_kits_item"] = "Artikal";
$lang["item_kits_items"] = "Stavke normativa";
$lang["item_kits_kit"] = "Normativ br.";
$lang["item_kits_name"] = "Naziv normativa";
$lang["item_kits_new"] = "Novi normativ";
$lang["item_kits_no_item_kits_to_display"] = "Nema normativa za prikaz";
$lang["item_kits_none_selected"] = "Niste odabrali nijedan normativ";
$lang["item_kits_one_or_multiple"] = "Stavka(e) normativa";
$lang["item_kits_quantity"] = "Količina";
$lang["item_kits_successful_adding"] = "Uspješno ste dodali normativ";
$lang["item_kits_successful_deleted"] = "Uspješno ste obrisali normativ";
$lang["item_kits_successful_updating"] = "Uspješno ste ažurirali normativ";
$lang["item_kits_update"] = "Ažuriranje normativa";
