<?php 

$lang["tables_loading"] = "Yükleniyor, lütfen bekleyin...";
$lang["tables_rows_per_page"] = "Sayfa başına {0} satır";
$lang["tables_page_from_to"] = "{2} kayıttan {0} - {1} görüntüleniyor";
$lang["tables_hide_show_pagination"] = "Sayfalandırmayı Gizle/Göster";
$lang["tables_refresh"] = "Yenile";
$lang["tables_toggle"] = "Değiştir";
$lang["tables_columns"] = "Sütun";
$lang["tables_all"] = "Tümü";
