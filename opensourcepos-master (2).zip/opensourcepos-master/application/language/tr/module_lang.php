<?php 

$lang["module_config"] = "Yapılandırma";
$lang["module_config_desc"] = "Yapılandırma bilgisi görme ve düzenleme";
$lang["module_customers"] = "Müşteriler";
$lang["module_customers_desc"] = "Ekleme, değiştirme, silme ve arama";
$lang["module_employees"] = "Personeller";
$lang["module_employees_desc"] = "Ekleme, değiştirme, silme ve arama";
$lang["module_giftcards"] = "Hediye Çekleri";
$lang["module_giftcards_desc"] = "Ekleme, değiştirme, silme ve arama";
$lang["module_home"] = "Giriş";
$lang["module_item_kits"] = "Ürün Setleri";
$lang["module_item_kits_desc"] = "Ekleme, değiştirme, silme ve arama";
$lang["module_items"] = "Ürünler";
$lang["module_items_desc"] = "Ekleme, değiştirme, silme ve arama";
$lang["module_receivings"] = "Alımlar";
$lang["module_receivings_desc"] = "Alım işlemleri";
$lang["module_reports"] = "Raporlar";
$lang["module_reports_desc"] = "Raporları görme";
$lang["module_sales"] = "Satış";
$lang["module_sales_desc"] = "Satış ve iade";
$lang["module_suppliers"] = "Sağlayıcılar";
$lang["module_suppliers_desc"] = "Ekleme, değiştirme, silme ve arama";
$lang["module_messages"] = "Messages";
$lang["module_messages_desc"] = "Send Messages to Customers, Suppliers, Employees et al.";
