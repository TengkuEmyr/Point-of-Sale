<?php 

$lang["item_kits_add_item"] = "إضافة مجموعة";
$lang["item_kits_cannot_be_deleted"] = "لايمكن حذف مجموعة/مجموعات";
$lang["item_kits_confirm_delete"] = "هل أنت متأكد أنك تريد حذف المجموعة؟";
$lang["item_kits_description"] = "وصف المجموعة";
$lang["item_kits_error_adding_updating"] = "خطاء فى إضافة/تحديث المجموعة";
$lang["item_kits_info"] = "معلومات المجموعة";
$lang["item_kits_item"] = "صنف";
$lang["item_kits_items"] = "أصناف";
$lang["item_kits_kit"] = "كود المجموعة";
$lang["item_kits_name"] = "اسم المجموعة";
$lang["item_kits_new"] = "مجموعة جديده";
$lang["item_kits_no_item_kits_to_display"] = "لاتوجد مجموعات لعرضها";
$lang["item_kits_none_selected"] = "لم تقم بإختيار مجموعات";
$lang["item_kits_one_or_multiple"] = "مجموعة/مجموعات";
$lang["item_kits_quantity"] = "الكمية";
$lang["item_kits_successful_adding"] = "لقد تم إضافة المجموعة بنجاح";
$lang["item_kits_successful_deleted"] = "لقد تم حذف المجموعة بنجاح";
$lang["item_kits_successful_updating"] = "لقد تم تحديث بيانات المجموعة بنجاح";
$lang["item_kits_update"] = "تحديث بيانات مجموعة";
