<?php 

$lang["module_config"] = "إعدادات الشركة";
$lang["module_config_desc"] = "تغيير إعدادات الشركة";
$lang["module_customers"] = "العملاء";
$lang["module_customers_desc"] = "إضافة، تحديث ، بحث و حذف العملاء";
$lang["module_employees"] = "الموظفين";
$lang["module_employees_desc"] = "إضافة، تحديث ، بحث و حذف الموظفين";
$lang["module_giftcards"] = "بطاقات الهدايا";
$lang["module_giftcards_desc"] = "إضافة، تحديث ، بحث و حذف بطاقات الهدايا";
$lang["module_home"] = "الرئيسية";
$lang["module_item_kits"] = "مجموعات الأصناف";
$lang["module_item_kits_desc"] = "إضافة، تحديث ، بحث و حذف مجموعات الأصناف";
$lang["module_items"] = "الأصناف";
$lang["module_items_desc"] = "إضافة، تحديث ، بحث و حذف الأصناف";
$lang["module_receivings"] = "استلام الأصناف";
$lang["module_receivings_desc"] = "معالجة أوامر الشراء و استلام الأصناف";
$lang["module_reports"] = "التقارير";
$lang["module_reports_desc"] = "عرض وتوليد التقارير";
$lang["module_sales"] = "المبيعات";
$lang["module_sales_desc"] = "معالجة المبيعات و المرتجعات";
$lang["module_suppliers"] = "الموردين";
$lang["module_suppliers_desc"] = "إضافة، تحديث ، بحث و حذف مجموعات الموردين";
$lang["module_messages"] = "الرسائل";
$lang["module_messages_desc"] = "إرسال رسائل للعملاء ، الموردين او الموظفين";
