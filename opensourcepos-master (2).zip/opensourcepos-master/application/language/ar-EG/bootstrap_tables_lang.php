<?php 

$lang["tables_loading"] = "جارى التحميل، برجاء الإنتظار";
$lang["tables_rows_per_page"] = "{0} صف بالصفحة";
$lang["tables_page_from_to"] = "عرض {0} إلى {1} من {2} صفوف";
$lang["tables_hide_show_pagination"] = "عرض/إخفاء أرقام الصفحات";
$lang["tables_refresh"] = "إعادة تحميل";
$lang["tables_toggle"] = "تغيير";
$lang["tables_columns"] = "أعمدة";
$lang["tables_all"] = "الجميع";
